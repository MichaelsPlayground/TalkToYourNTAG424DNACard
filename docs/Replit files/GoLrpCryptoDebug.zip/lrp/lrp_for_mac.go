package lrp

import (
	//"github.com/aead/cmac"
  "main/cmac"
	"fmt"
)

type LrpForMAC struct {
	LrpCipher
}

// This overrides the Encrypt method on LrpCipher to only run the EvalLRP
func (lrp *LrpForMAC) Encrypt(dst, src []byte) {
  fmt.Println("## LrpForMAC Encrypt")
  fmt.Println("dst " + BytesToHex(dst))
  fmt.Println("src " + BytesToHex(src))
	result := lrp.EvalLRP(nibbles(src), true)
  fmt.Println("result " + BytesToHex(result))
  fmt.Println("shortening result to blocksize")
  
	copy(dst[0:blocksize], result)
  fmt.Println("returns result " + BytesToHex(result))
}

// Convenience function for doing a CMAC
func (lrp *LrpForMAC) CMAC(msg []byte) []byte {
  fmt.Println("## LrpForMAC CMAC")
  fmt.Println("msg " + BytesToHex(msg))
	h, _ := cmac.NewWithTagSize(lrp, 16)
	h.Write(msg)
  fmt.Println("returns " + BytesToHex(h.Sum(nil)))
	return h.Sum(nil)
}

// Convenience function for doing an NXP-style short CMAC
func (lrp *LrpForMAC) ShortCMAC(msg []byte) []byte {
  fmt.Println("## LrpForMAC ShortCMAC")
  fmt.Println("msg " + BytesToHex(msg))
	mac := lrp.CMAC(msg)
  fmt.Println("returns " + BytesToHex([]byte { mac[1], mac[3], mac[5], mac[7], mac[9], mac[11], mac[13], mac[15]}))
	return []byte { mac[1], mac[3], mac[5], mac[7], mac[9], mac[11], mac[13], mac[15] }
}
