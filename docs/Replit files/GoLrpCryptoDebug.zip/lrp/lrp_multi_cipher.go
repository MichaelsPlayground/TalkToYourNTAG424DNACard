package lrp

import (
	"encoding/hex"
	"fmt"
)

// This is based off of NXP document 12304

type LrpMultiCipher struct {
	MainKey []byte
	M       int      // Nibble Size
	P       [][]byte // Plaintexts
}

// Creates a new multi-cipher with a given nibble size
func NewMultiCipher(key []byte, nibbleSize int) *LrpMultiCipher {
  fmt.Println("## NewMultiCipher with key and nibbleSize")
  fmt.Println(" key " + BytesToHex(key))
  
	lrp := LrpMultiCipher{
		MainKey: key,
		M:       nibbleSize,
		P:       [][]byte{},
  
	}
  fmt.Println("key: " + BytesToHex(key))
  fmt.Println("nibbleSize: %i", nibbleSize)
	lrp.Reset()
  return &lrp
}

// Create a multi-cipher with the standard nibble size
func NewStandardMultiCipher(key []byte) *LrpMultiCipher {
  fmt.Println("## NewStandardMultiCipher")
  fmt.Println(" with key " + BytesToHex(key))
	return NewMultiCipher(key, 4)
}

// Recalculates all of the shared plaintexts of the multi-cipher
func (lrp *LrpMultiCipher) Reset() {
  fmt.Println("## Reset")
	// Algorithm 1 (pg. 5)
	numPlaintexts := 1 << (lrp.M)
	lrp.P = make([][]byte, numPlaintexts)

	h := encryptWith(lrp.MainKey, upper)
	for i := 0; i < numPlaintexts; i++ {
		lrp.P[i] = encryptWith(h, lower)
		h = encryptWith(h, upper)
	}
}

// Generates a cipher with the specific key number from the multi-cypher.
func (lrp LrpMultiCipher) Cipher(idx int) *LrpCipher {
	// Algorithm 2 (pg. 5)
  fmt.Println("## LrpMultiCipher Cipher")
  fmt.Println("idx: %i", idx)
	h := encryptWith(lrp.MainKey, lower)

	for i := 0; i < idx; i++ {
		h = encryptWith(h, upper)
	}
	k := encryptWith(h, lower)
  
  fmt.Println("key for idx: " + BytesToHex(k))
  
	return &LrpCipher{
		Multi:   &lrp,
		Key:     k,
		Counter: 0,
		Encrypting: true,
	}
}

// Generates a cipher specifically for use for MAC-ing (uses the LRP primitive rather than the encryption).
// Note that the ``Encrypt'' function doesn't actually encrypt/decrypt, but MAC processes utilize that interface.
func (lrp LrpMultiCipher) CipherForMAC(idx int) *LrpForMAC {
  fmt.Println("## LrpMultiCipher CipherForMAC")
  fmt.Println("idx: %i", idx)
	c := lrp.Cipher(idx)
  fmt.Println("MAC key for idx: " + BytesToHex(c.Key))
	return &LrpForMAC{
		*c,
	}
}

func BytesToHex(input []byte)(string){
  return hex.EncodeToString(input)
}
