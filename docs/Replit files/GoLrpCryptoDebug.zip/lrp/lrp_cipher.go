package lrp

import (
	"fmt"
)

type LrpCipher struct {
	Multi       *LrpMultiCipher
	Key         []byte
	Counter     uint64
	CounterSize int
	Encrypting  bool
}

// Generates a decrypting cipher, compatible with cipher.BlockMode
func (lrp *LrpCipher) Decrypter() *LrpCipher {
	newCipher := LrpCipher{
		Multi:      lrp.Multi,
		Key:        lrp.Key,
		Counter:    lrp.Counter,
		Encrypting: false,
	}
  fmt.Println("## Decryptor")
	return &newCipher
}

// Generates a encrypting cipher, compatible with cipher.BlockMode
func (lrp *LrpCipher) Encrypter() *LrpCipher {
	newCipher := LrpCipher{
		Multi:      lrp.Multi,
		Key:        lrp.Key,
		Counter:    lrp.Counter,
		Encrypting: true,
	}
  fmt.Println("## Encryptor")
	return &newCipher
}

// Number of bytes in a block
func (lrp *LrpCipher) BlockSize() int {
  fmt.Println("## BlockSize %i", blocksize)
	return blocksize
}

// This is the fundamental primitive used for encryption/decryption
func (lrp *LrpCipher) EvalLRP(x []int, final bool) []byte {
  fmt.Println("## EvalLRP with int array = nibbles")
  for _, x := range x {
          fmt.Printf("- %d ", x)
        }
  fmt.Println("");
  
	l := len(x)

	// Algorithm 3 (pg. 6)
	y := lrp.Key

	for i := 0; i < l; i++ {
		p := lrp.Multi.P[x[i]]
		y = encryptWith(y, p)
	}
	if final {
		y = encryptWith(y, zeroBlock)
	}
  fmt.Println("returns " + BytesToHex(y))
	return y
}

/* Fundamental Primitives */

// Encrypts the given blocks from src to dst.
// Based on the smaller of src/dst.  Requires
// that src is only full blocks.
func (lrp *LrpCipher) EncryptBlocks(dst, src []byte) {
  fmt.Println("## EncryptBlocks")
  fmt.Println("dst " + BytesToHex(dst))
  fmt.Println("src " + BytesToHex(src))
	// Algorithm 4 (pg. 7)
	srcblocks := len(src) / blocksize
	numblocks := len(dst) / blocksize
	if srcblocks < numblocks {
		numblocks = srcblocks
	}

	for i := 0; i < numblocks; i++ {
		blockstart := i * blocksize
		blockend := blockstart + blocksize
		block := src[blockstart:blockend]
		x := lrp.CounterPieces()
		// l := len(x)
		y := lrp.EvalLRP(x, true)
		encryptedBlock := encryptWith(y, block)
		copy(dst[blockstart:blockend], encryptedBlock)
    fmt.Println("** increase counter")
		lrp.Counter++
    fmt.Println("** increased counter to %#v: ", lrp.Counter)
	}
}

// Decrypt the given blocks in src to dst.  Requires
// full blocks.
func (lrp *LrpCipher) DecryptBlocks(dst, src []byte) {
  fmt.Println("## DecryptBlocks")
  fmt.Println("dst " + BytesToHex(dst))
  fmt.Println("src " + BytesToHex(src))
	// Algorithm 5 (pg. 8)
	srcblocks := len(src) / blocksize
	numblocks := len(dst) / blocksize
	if srcblocks < numblocks {
		numblocks = srcblocks
	}

	for i := 0; i < numblocks; i++ {
		blockstart := i * blocksize
		blockend := blockstart + blocksize
		block := src[blockstart:blockend]
		x := lrp.CounterPieces()
		// l := len(x)
		y := lrp.EvalLRP(x, true)
		decryptedBlock := decryptWith(y, block)
		copy(dst[blockstart:blockend], decryptedBlock)
    fmt.Println("** increase counter")
		lrp.Counter++
    fmt.Println("** increased counter to %#v: ", lrp.Counter)
    
	}
}

/* Standard BlockMode interface functions */
func (lrp *LrpCipher) CryptBlocks(dst, src []byte) {
  fmt.Println("## CryptBlocks")
  fmt.Println("dst " + BytesToHex(dst))
  fmt.Println("src " + BytesToHex(src))
	if lrp.Encrypting {
		lrp.EncryptBlocks(dst, src)
	} else {
		lrp.DecryptBlocks(dst, src)
	}
}

/* Standard cipher.Block interface functions */

// Encrypt a single block
func (lrp *LrpCipher) Encrypt(dst, src []byte) {
  fmt.Println("## Encrypt")
  fmt.Println("dst " + BytesToHex(dst))
  fmt.Println("src " + BytesToHex(src))
	lrp.EncryptBlocks(dst[0:blocksize], src[0:blocksize])
}

// Decrypt a single block
func (lrp *LrpCipher) Decrypt(dst, src []byte) {
  fmt.Println("## Decrypt")
  fmt.Println("dst " + BytesToHex(dst))
  fmt.Println("src " + BytesToHex(src))
	lrp.DecryptBlocks(dst[0:blocksize], src[0:blocksize])
}

/* Convenience functions */

// Encrypt the entire message.  All non-even blocks are padded.
// Setting padEvenBlocks to true will give you padded blocks no
// matter what.  This is normally what you want, but NXP has
// a few cases of non-padded encryption.
func (lrp *LrpCipher) EncryptAll(src []byte, padEvenBlocks bool) []byte {
  fmt.Println("## EncryptAll")
  fmt.Println("src " + BytesToHex(src))
  fmt.Println("padEvenBlocks: %t", padEvenBlocks)
	oldcounter := lrp.Counter
	length := len(src)
	var dst []byte

	if length == 0 {
		dst = make([]byte, blocksize)
		lrp.CryptBlocks(dst, fullBlockPadding)
	} else {
		if len(src)%blocksize == 0 {
			if padEvenBlocks {
				newsrc := make([]byte, len(src))
				copy(newsrc, src)
				newsrc = append(newsrc, fullBlockPadding...)
				dst = make([]byte, len(newsrc))
				lrp.CryptBlocks(dst, newsrc)
			} else {
				dst = make([]byte, len(src))
				lrp.CryptBlocks(dst, src)
			}
		} else {
			numblocks := (len(src) / blocksize) + 1
			newsrc := make([]byte, numblocks*blocksize)
			dst = make([]byte, len(newsrc))
			copy(newsrc, src)
			newsrc[len(src)] = 0x80
			lrp.CryptBlocks(dst, newsrc)
		}
	}
	lrp.Counter = oldcounter
	return dst
}

// Decrypt the entire message.  removePadding tells whether or not
// it was originally padded, and, therefore, whether to remove the
// padding before it is returned.
func (lrp *LrpCipher) DecryptAll(src []byte, removePadding bool) []byte {
  fmt.Println("## DecryptAll")
  fmt.Println("src " + BytesToHex(src))
  fmt.Println("removePadding bool %t", removePadding)
	dst := make([]byte, len(src))
	lrp.DecryptBlocks(dst, src)

	if removePadding {
		dividerByteIndex := len(dst) - 1
		for dst[dividerByteIndex] != 0x80 {
			dividerByteIndex--
		}
		return dst[0:dividerByteIndex]
	} else {
		return dst
	}
}

// Breaks the block counter into nibbles for the EvalLRP primitive
func (lrp *LrpCipher) CounterPieces() []int {
  fmt.Println("## CounterPieces")
	pieces := []int{}

	bits := lrp.Multi.M
	bitmask := uint64((1 << bits) - 1)

	ctr := lrp.Counter
	for true {
		if lrp.CounterSize == 0 {
			if ctr == 0 {
				break
			}
		} else {
			if len(pieces) == lrp.CounterSize {
				break
			}
		}

		low := ctr & bitmask
		pieces = append([]int{int(low)}, pieces...)
		ctr = ctr >> bits
	}

	return pieces
}
