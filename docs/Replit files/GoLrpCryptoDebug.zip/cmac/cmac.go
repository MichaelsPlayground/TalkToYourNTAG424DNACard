// Copyright (c) 2016 Andreas Auernhammer. All rights reserved.
// Use of this source code is governed by a license that can be
// found in the LICENSE file.

// Package cmac implements the fast CMAC MAC based on
// a block cipher. This mode of operation fixes security
// deficiencies of CBC-MAC (CBC-MAC is secure only for
// fixed-length messages). CMAC is equal to OMAC1.
// This implementations supports block ciphers with a
// block size of:
//	-   64 bit
//	-  128 bit
//	-  256 bit
//	-  512 bit
//	- 1024 bit
// Common ciphers like AES, Serpent etc. operate on 128 bit
// blocks. 256, 512 and 1024 are supported for the Threefish
// tweakable block cipher. Ciphers with 64 bit blocks are
// supported, but not recommened.
// CMAC (with AES) is specified in RFC 4493 and RFC 4494.
package cmac // import "github.com/aead/cmac"

import (
	"crypto/cipher"
	"crypto/subtle"
	"errors"
	"hash"
  "encoding/hex"
	"fmt"
)

const (
	// minimal irreducible polynomial for blocksize
	p64   = 0x1b    // for 64  bit block ciphers
	p128  = 0x87    // for 128 bit block ciphers (like AES)
	p256  = 0x425   // special for large block ciphers (Threefish)
	p512  = 0x125   // special for large block ciphers (Threefish)
	p1024 = 0x80043 // special for large block ciphers (Threefish)
)

var (
	errUnsupportedCipher = errors.New("cipher block size not supported")
	errInvalidTagSize    = errors.New("tags size must between 1 and the cipher's block size")
)

// Sum computes the CMAC checksum with the given tagsize of msg using the cipher.Block.
func Sum(msg []byte, c cipher.Block, tagsize int) ([]byte, error) {
  fmt.Println("## CMAC Sum")
  fmt.Println("msg: " + BytesToHex(msg))
  fmt.Println("cipher.Block")
  fmt.Println("tagsize: %i", tagsize)
	h, err := NewWithTagSize(c, tagsize)
	if err != nil {
		return nil, err
	}
	h.Write(msg)
  fmt.Println("returns: " + BytesToHex(h.Sum(nil)))
	return h.Sum(nil), nil
}

// Verify computes the CMAC checksum with the given tagsize of msg and compares
// it with the given mac. This functions returns true if and only if the given mac
// is equal to the computed one.
func Verify(mac, msg []byte, c cipher.Block, tagsize int) bool {
  fmt.Println("## CMAC Verify")
  fmt.Println("msg: " + BytesToHex(msg))
  fmt.Println("cipher.Block")
  fmt.Println("tagsize: %i", tagsize)
	sum, err := Sum(msg, c, tagsize)
	if err != nil {
		return false
	}
  fmt.Println("returns bool %t", subtle.ConstantTimeCompare(mac, sum) == 1)
	return subtle.ConstantTimeCompare(mac, sum) == 1
}

// New returns a hash.Hash computing the CMAC checksum.
func New(c cipher.Block) (hash.Hash, error) {
  fmt.Println("## CMAC New")
	return NewWithTagSize(c, c.BlockSize())
}

// NewWithTagSize returns a hash.Hash computing the CMAC checksum with the
// given tag size. The tag size must between the 1 and the cipher's block size.
func NewWithTagSize(c cipher.Block, tagsize int) (hash.Hash, error) {
  fmt.Println("## CMAC NewWithTagSize")
  fmt.Println("cipher.Block")
  fmt.Println("tagsize: %i", tagsize)
  
	blocksize := c.BlockSize()

	if tagsize <= 0 || tagsize > blocksize {
		return nil, errInvalidTagSize
	}

	var p int
	switch blocksize {
	default:
		return nil, errUnsupportedCipher
	case 8:
		p = p64
	case 16:
		p = p128
	case 32:
		p = p256
	case 64:
		p = p512
	case 128:
		p = p1024
	}

	m := &macFunc{
		cipher: c,
		k0:     make([]byte, blocksize),
		k1:     make([]byte, blocksize),
		buf:    make([]byte, blocksize),
	}
	m.tagsize = tagsize

  fmt.Println("CMAC start k0 " + BytesToHex(m.k0))
  
	c.Encrypt(m.k0, m.k0)
  fmt.Println("CMAC c.Encrypt k0 " + BytesToHex(m.k0))
	v := shift(m.k0, m.k0)

  m.k0[blocksize-1] ^= byte(subtle.ConstantTimeSelect(v, p, 0))
  
  //m.k0[blocksize-1] ^= byte(p);
  fmt.Println("p: %i", p)
  fmt.Println("CMAC k0 after blocksize.." + BytesToHex(m.k0))
	v = shift(m.k1, m.k0)
	m.k1[blocksize-1] ^= byte(subtle.ConstantTimeSelect(v, p, 0))
  fmt.Println("returns m");
  fmt.Println("returns m.k0 " + BytesToHex(m.k0))
  fmt.Println("returns m.k1 " + BytesToHex(m.k1))
  fmt.Println("returns m.buf " + BytesToHex(m.buf))
	return m, nil
}

// The CMAC message auth. function
type macFunc struct {
	cipher  cipher.Block
	k0, k1  []byte
	buf     []byte
	off     int
	tagsize int
}

func (h *macFunc) Size() int { 
  fmt.Println("## CMAC Size")
  return h.cipher.BlockSize() }

func (h *macFunc) BlockSize() int { 
  fmt.Println("## CMAC BlockSize")
  return h.cipher.BlockSize() }

func (h *macFunc) Reset() {
  fmt.Println("## CMAC Reset")
  
	for i := range h.buf {
		h.buf[i] = 0
	}
	h.off = 0
}

func (h *macFunc) Write(msg []byte) (int, error) {
  fmt.Println("## CMAC Write")
  fmt.Println("msg: " + BytesToHex(msg))
	bs := h.BlockSize()
	n := len(msg)

	if h.off > 0 {
    fmt.Println("if h.off > 0")
		dif := bs - h.off
		if n > dif {
			xor(h.buf[h.off:], msg[:dif])
			msg = msg[dif:]
			h.cipher.Encrypt(h.buf, h.buf)
			h.off = 0
		} else {
			xor(h.buf[h.off:], msg)
			h.off += n
			return n, nil
		}
	}

	if length := len(msg); length > bs {
    fmt.Println("if length := len(msg); length > bs")
    fmt.Println("length %i", length)
    fmt.Println("bs %i", bs)
		nn := length & (^(bs - 1))
    fmt.Println("nn %i", nn)
		if length == nn {
			nn -= bs
		}
    fmt.Println("nn %i", nn)
		for i := 0; i < nn; i += bs {
      fmt.Println("for i < nn i: %i", i)
      fmt.Println("h.buf DEST: " + BytesToHex(h.buf))
      fmt.Println("msg   SRC : " + BytesToHex(msg[i:i+bs]))
			xor(h.buf, msg[i:i+bs])
      fmt.Println("before h.cipher.Encrypt buf DEST: " + BytesToHex(h.buf))
			h.cipher.Encrypt(h.buf, h.buf)
		}
		msg = msg[nn:]
	}

  fmt.Println("Write before if length := len(msg); length > 0")
  fmt.Println("Write buf: " + BytesToHex(h.buf))
  fmt.Println("Write msg: " + BytesToHex(msg))
  
	if length := len(msg); length > 0 {
		xor(h.buf[h.off:], msg)
		h.off += length
	}

  fmt.Println("Write final buf: " + BytesToHex(h.buf))
  fmt.Println("Write final msg: " + BytesToHex(msg))
  fmt.Println("Write final n: %i", n)
	return n, nil
}

func (h *macFunc) Sum(b []byte) []byte {
  fmt.Println("## CMAC Sum")
  fmt.Println("b: " + BytesToHex(b))
	blocksize := h.cipher.BlockSize()

  fmt.Println("Sum started")
  fmt.Println("b: " + BytesToHex(b))
	// Don't change the buffer so the
	// caller can keep writing and suming.
	hash := make([]byte, blocksize)
  fmt.Println("k0: " + BytesToHex(h.k0))
	if h.off < blocksize {
		copy(hash, h.k1)
    fmt.Println("hash=k1: " + BytesToHex(hash))
	} else {
		copy(hash, h.k0)
    fmt.Println("hash=k0: " + BytesToHex(hash))
	}

	xor(hash, h.buf)
  fmt.Println("xor hash: " + BytesToHex(hash))
	if h.off < blocksize {
		hash[h.off] ^= 0x80
    fmt.Println("h.off < blocksize")
	}
  fmt.Println("hash after ^= 0x80: " + BytesToHex(hash))
  fmt.Println("hash before last encrypt: " + BytesToHex(hash))
	h.cipher.Encrypt(hash, hash)
  fmt.Println("hash after  last encrypt: " + BytesToHex(hash))
  fmt.Println("returns: " + BytesToHex(append(b, hash[:h.tagsize]...)))
	return append(b, hash[:h.tagsize]...)
}

func shift(dst, src []byte) int {
  fmt.Println("## CMAC shift")
  fmt.Println("dst: " + BytesToHex(dst))
  fmt.Println("src: " + BytesToHex(src))
  
	var b, bit byte
	for i := len(src) - 1; i >= 0; i-- { // a range would be nice
		bit = src[i] >> 7
		dst[i] = src[i]<<1 | b
		b = bit
	}
  fmt.Println("returns: %i", int(b))
  fmt.Println("dst: " + BytesToHex(dst))
	return int(b)
}

func BytesToHex(input []byte)(string){
  return hex.EncodeToString(input)
}
